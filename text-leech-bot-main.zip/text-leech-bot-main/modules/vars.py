# SudoR2spr WOODcraft
# Add your details here and then deploy by clicking on HEROKU Deploy button

api_id = "1701393"
api_hash = "96089a340f5892fd06aea683cbfb73c6"
bot_token = "6872135659:AAwwm1jsMGNOFJnuICL_a1coI6CI6udAY6F4"
